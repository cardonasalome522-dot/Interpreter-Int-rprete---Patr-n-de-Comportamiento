﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{
    public sealed class GreaterThanExpression : IExpression
    {
        private readonly string _attribute;
        private readonly int _limit;

        public GreaterThanExpression(string attribute, int limit)
        {
            _attribute = attribute;
            _limit = limit;
        }

        public bool Interpret(CustomerContext context)
        {
            return context.TryGet<int>(_attribute, out var value) && value > _limit;
        }
    }

}
