﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{
    public sealed class LastVisitWithinExpression : IExpression
    {
        private readonly TimeSpan _threshold;

        public LastVisitWithinExpression(TimeSpan threshold)
        {
            _threshold = threshold;
        }

        public bool Interpret(CustomerContext context)
        {
            if (!context.TryGet<DateTime>("lastVisit", out var lastVisit))
            {
                return false;
            }

            var elapsed = DateTime.UtcNow - lastVisit;
            return elapsed <= _threshold;
        }
    }
}
