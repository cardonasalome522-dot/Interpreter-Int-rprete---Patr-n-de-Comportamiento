﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{
    public sealed class NotExpression : IExpression
    {
        private readonly IExpression _expression;

        public NotExpression(IExpression expression)
        {
            _expression = expression;
        }

        public bool Interpret(CustomerContext context)
        {
            return !_expression.Interpret(context);
        }
    }

}
