﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{
    public sealed class EqualsExpression : IExpression
    {
        private readonly string _attribute;
        private readonly string _expectedValue;

        public EqualsExpression(string attribute, string expectedValue)
        {
            _attribute = attribute ?? throw new ArgumentNullException(nameof(attribute));
            _expectedValue = expectedValue ?? throw new ArgumentNullException(nameof(expectedValue));
        }

        public bool Interpret(CustomerContext context)
        {
            return context.TryGet<string>(_attribute, out var value) &&
                   string.Equals(value, _expectedValue, StringComparison.OrdinalIgnoreCase);
        }
    }

}
