﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{

    public sealed class CustomerContext
    {
        private readonly Dictionary<string, object> _attributes;

        public CustomerContext(IDictionary<string, object> attributes)
        {
            _attributes = new Dictionary<string, object>(attributes);
        }

        public bool TryGet<T>(string key, out T value)
        {
            if (_attributes.TryGetValue(key, out var raw) && raw is T converted)
            {
                value = converted;
                return true;
            }

            value = default!;
            return false;
        }
    }
}

//este lo que realiza es definir la clase CustomerContext que representa el contexto de un cliente.
//Esta clase contiene un diccionario de atributos que se pueden consultar mediante el método TryGet.
//El método TryGet intenta obtener un valor del diccionario basado en una clave y lo convierte al tipo especificado.
//Si la clave existe y el valor se puede convertir al tipo deseado, devuelve true y asigna el valor a la variable de salida;
//de lo contrario, devuelve false y asigna el valor predeterminado del tipo a la variable de salida.