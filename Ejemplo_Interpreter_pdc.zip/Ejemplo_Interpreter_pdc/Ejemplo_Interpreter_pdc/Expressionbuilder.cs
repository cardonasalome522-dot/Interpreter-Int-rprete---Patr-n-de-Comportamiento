﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{
    public sealed class ExpressionBuilder
    {
        public IExpression CategoryIs(string category) =>
            new EqualsExpression("category", category);

        public IExpression PurchasesGreaterThan(int minimum) =>
            new GreaterThanExpression("purchases", minimum);

        public IExpression LastVisitWithin(TimeSpan duration) =>
            new LastVisitWithinExpression(duration);

        public IExpression And(IExpression left, IExpression right) =>
            new AndExpression(left, right);

        public IExpression Or(IExpression left, IExpression right) =>
            new OrExpression(left, right);

        public IExpression Not(IExpression expression) =>
            new NotExpression(expression);
    }
}
