﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{
    public interface IExpression
    {
        bool Interpret(CustomerContext context);
    }
}

//este lo que hace es definir la interfaz IExpression que tiene un método Interpret
//que toma un CustomerContext como parámetro y devuelve un valor booleano. Esta interfaz se utilizará para implementar diferentes expresiones que pueden ser interpretadas en el contexto de un cliente.