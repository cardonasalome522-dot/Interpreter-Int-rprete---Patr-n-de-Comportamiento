﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_Interpreter_pdc
{
    public static class InterpreterApp
    {
        public static void Main()
        {
            var builder = new ExpressionBuilder();
            IExpression segment = builder.Or(
                builder.And(
                    builder.CategoryIs("PREMIUM"),
                    builder.PurchasesGreaterThan(50)
                ),
                builder.LastVisitWithin(TimeSpan.FromDays(30))
            );

            var customerA = new CustomerContext(new Dictionary<string, object>
            {
                ["category"] = "PREMIUM",
                ["purchases"] = 80,
                ["lastVisit"] = DateTime.UtcNow.AddDays(-60)
            });

            var customerB = new CustomerContext(new Dictionary<string, object>
            {
                ["category"] = "REGULAR",
                ["purchases"] = 10,
                ["lastVisit"] = DateTime.UtcNow.AddDays(-5)
            });

            Console.WriteLine($"Does customer A match the segment? {segment.Interpret(customerA)}");
            Console.WriteLine($"Does customer B match the segment? {segment.Interpret(customerB)}");
        }
    }
}
