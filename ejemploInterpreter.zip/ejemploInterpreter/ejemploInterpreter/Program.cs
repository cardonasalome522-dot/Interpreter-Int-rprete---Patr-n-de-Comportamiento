﻿using ejemploInterpreter;

class Program
{
    static void Main()
    {
        IExpresion numero1 = new Numero(10);
        IExpresion numero2 = new Numero(5);

        IExpresion suma = new Suma(numero1, numero2);

        Console.WriteLine("10 + 5 = " + suma.Interpretar());


        IExpresion resta = new Resta(numero1, numero2);

        Console.WriteLine("10 - 5 = " + resta.Interpretar());


        IExpresion multiplicacion = new Multiplicacion(numero1, numero2);

        Console.WriteLine("10 * 5 = " + multiplicacion.Interpretar());


        IExpresion division = new Division(numero1, numero2);

        Console.WriteLine("10 / 5 = " + division.Interpretar());
    }
}