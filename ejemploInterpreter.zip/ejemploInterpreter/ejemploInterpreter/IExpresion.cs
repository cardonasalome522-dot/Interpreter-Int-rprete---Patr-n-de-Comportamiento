﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejemploInterpreter
{
    public interface IExpresion
    {
        int Interpretar();
    }
}
