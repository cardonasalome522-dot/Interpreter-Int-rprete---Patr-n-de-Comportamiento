﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejemploInterpreter
{
    public class Division : IExpresion
    {
        private IExpresion izquierda;
        private IExpresion derecha;

        public Division(IExpresion izquierda, IExpresion derecha)
        {
            this.izquierda = izquierda;
            this.derecha = derecha;
        }

        public int Interpretar()
        {
            return izquierda.Interpretar() / derecha.Interpretar();
        }
    }
}
