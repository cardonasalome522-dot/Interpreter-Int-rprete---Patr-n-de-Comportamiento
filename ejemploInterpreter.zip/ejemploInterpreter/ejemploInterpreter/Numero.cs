﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejemploInterpreter
{
    public class Numero : IExpresion
    {
        private int numero;

        public Numero(int numero)
        {
            this.numero = numero;
        }

        public int Interpretar()
        {
            return numero;
        }
    }
}
